mejor descargalo de jquery.com :P

Att: El Freddo