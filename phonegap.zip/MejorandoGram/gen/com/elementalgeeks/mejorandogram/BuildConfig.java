/** Automatically generated file. DO NOT MODIFY */
package com.elementalgeeks.mejorandogram;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}